//
//  QYProgressView.h
//  1 QYProgressView
//
//  Created by 蓝科 on 16/4/27.
//  Copyright © 2016年 千羽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QYProgressView : UIView
//设置进度条的属性
@property (nonatomic, assign) CGFloat progress;

/**
 *  创建一个环形进度条视图
 *
 *  @param frame           尺寸
 *  @param lineWidth       进度条宽度
 *  @param foregroundColor 进度条前景色
 *  @param backgroundColor 进度条背景色
 *  @param labelFont       显示进度的标签的字体
 *
 *  @return 环形进度条视图
 */

- (instancetype)initWithFrame:(CGRect)frame andLineWidth:(CGFloat)lineWidth andForegroundColor:(UIColor *)foregroundColor andBackgroundColor:(UIColor *)backgroundColor andLabelFont:(UIFont *)labelFont andMargin:(CGFloat)margin;

+ (instancetype)progressViewWithFrame:(CGRect)frame andLineWidth:(CGFloat)lineWidth andForegroundColor:(UIColor *)foregroundColor andBackgroundColor:(UIColor *)backgroundColor andLabelFont:(UIFont *)labelFont andMargin:(CGFloat)margin;

@end
