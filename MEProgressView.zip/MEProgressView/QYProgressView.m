//
//  QYProgressView.m
//  1 QYProgressView
//
//  Created by 蓝科 on 16/4/27.
//  Copyright © 2016年 千羽. All rights reserved.
//

#import "QYProgressView.h"

@interface QYProgressView ()
{
    CGFloat _lineWidth;//进度条的宽度
    UIColor *_foregroundColor;//进度条的前景颜色
    UIColor *_backgroundColor;//进度条的背景颜色
    CGFloat _margin;//边距
    UIFont *_labelFont;//显示进度标签的字体
}
@property (nonatomic ,strong) UILabel *progressLabel;
@end
@implementation QYProgressView

+ (instancetype)progressViewWithFrame:(CGRect)frame andLineWidth:(CGFloat)lineWidth andForegroundColor:(UIColor *)foregroundColor andBackgroundColor:(UIColor *)backgroundColor andLabelFont:(UIFont *)labelFont andMargin:(CGFloat)margin
{
    return [[QYProgressView alloc] initWithFrame:frame
                                   andLineWidth:lineWidth
                                   andForegroundColor:foregroundColor
                                   andBackgroundColor:backgroundColor
                                   andLabelFont:labelFont andMargin:margin];
}

- (instancetype)initWithFrame:(CGRect)frame andLineWidth:(CGFloat)lineWidth andForegroundColor:(UIColor *)foregroundColor andBackgroundColor:(UIColor *)backgroundColor andLabelFont:(UIFont *)labelFont andMargin:(CGFloat)margin
{
    self = [super initWithFrame:frame];
    if (self) {
        _lineWidth = lineWidth;
        _foregroundColor = foregroundColor;
        _backgroundColor = backgroundColor;
        _labelFont = labelFont;
        _margin = margin;
        
    }
    return self;
}
#pragma mark - 懒加载
- (UILabel *)progressLabel
{
    if (_progressLabel == nil) {
        _progressLabel = [[UILabel alloc] initWithFrame:self.bounds];
        _progressLabel.font = _labelFont;
    }
    return _progressLabel;
}

//重写进度条的setter方法
- (void)setProgress:(CGFloat)progress
{
    _progress = progress;
    //设置progressLabel里的显示的进度
    self.progressLabel.text = [NSString stringWithFormat:@"%.f%%",progress*100];
    //手动调用重绘方法drawRect
    [self setNeedsDisplay];
}

//画进度环
- (void)drawRect:(CGRect)rect
{
    //环中心
    CGPoint center = CGPointMake(rect.size.width*0.5, rect.size.height*0.5);
    //环半径
    CGFloat radius = rect.size.width*0.5-_lineWidth*0.5-_margin;
    //环起始角度
    CGFloat startAngle = -M_PI_2;
    //环转的角度
    CGFloat angle = M_PI*2*self.progress;
    //环旋转后的角度
    CGFloat endAngle = startAngle + angle;
    //画进度条
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path addArcWithCenter:center
                    radius:radius
                    startAngle:startAngle
                    endAngle:endAngle
                    clockwise:YES];
    //进度条宽度
    [path setLineWidth:_lineWidth];
    //前景颜色
    [_foregroundColor setStroke];
    [path stroke];
    
    //画一个环形背景
    UIBezierPath *backPath = [UIBezierPath bezierPath];
    [backPath addArcWithCenter:center
                        radius:radius
                    startAngle:0
                      endAngle:M_PI*2
                     clockwise:YES];
    [backPath setLineWidth:_lineWidth];
    [_backgroundColor setStroke];
    [backPath stroke];
}


























@end
